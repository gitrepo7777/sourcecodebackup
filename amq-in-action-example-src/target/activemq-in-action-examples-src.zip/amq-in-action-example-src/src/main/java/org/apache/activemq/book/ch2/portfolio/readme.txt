1. Start ActiveMQ: ${ACTIVEMQ_HOME}/bin/activemq xbean:src/main/resources/org/apache/activemq/book/ch2/activemq.xml
2. Run Publisher class with desired stock as parameters (e.g. IONA JAVA)
3. Run Consumer class with desired stock as parameters (e.g. IONA JAVA)
